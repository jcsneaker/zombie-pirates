package de.bmw.ramsestrianglerenderer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import de.bmw.ramses.RamsesTriangleRenderer;

public class MainActivity extends AppCompatActivity implements SurfaceHolder.Callback{

    static {
        System.loadLibrary("ramses-shared-lib-android-egl-es-3-0");
    }
;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SurfaceView surfaceView = (SurfaceView) findViewById(R.id.surfaceView);
        surfaceView.getHolder().addCallback(this);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        if (ramsesTriangleRenderer != null)
        {
            ramsesTriangleRenderer.dispose();
        }

        ramsesTriangleRenderer = new RamsesTriangleRenderer(holder.getSurface(), width, height);
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        ramsesTriangleRenderer.dispose();
        ramsesTriangleRenderer = null;
    }

    private RamsesTriangleRenderer ramsesTriangleRenderer;
}
